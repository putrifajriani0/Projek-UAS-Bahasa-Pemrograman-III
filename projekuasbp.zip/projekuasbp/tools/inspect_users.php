<?php
// Direct DB connection using credentials from app/Config/Database.php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'db_e_voting';
$port = 3306;

// Create connection using mysqli
$mysqli = new mysqli($host, $user, $pass, $db, $port);
if ($mysqli->connect_errno) {
    echo "Connect failed: " . $mysqli->connect_error . PHP_EOL;
    exit(1);
}

$result = $mysqli->query("SHOW COLUMNS FROM users");
if (!$result) {
    echo "Query error: " . $mysqli->error . PHP_EOL;
    exit(1);
}

$rows = [];
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}

echo json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;
$mysqli->close();
