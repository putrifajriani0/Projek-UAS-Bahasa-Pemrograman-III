<?php
$mysqli=new mysqli('localhost','root','','db_e_voting',3306);
if($mysqli->connect_errno){
    echo 'connect fail: '.$mysqli->connect_error.PHP_EOL;
    exit(1);
}
$r=$mysqli->query('SHOW CREATE TABLE users');
if(!$r){
    echo 'query error: '.$mysqli->error.PHP_EOL; exit(1);
}
$row=$r->fetch_assoc();
echo $row['Create Table'].PHP_EOL;
$mysqli->close();
