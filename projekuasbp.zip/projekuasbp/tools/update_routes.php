<?php
$file = 'app/Config/Routes.php';
$content = file_get_contents($file);

// Replace the root route
$content = str_replace(
    "// Redirect home to login\n\$routes->get('/', 'Auth::index');",
    "// Redirect home to welcome page\n\$routes->get('/', 'Auth::welcome');",
    $content
);

file_put_contents($file, $content);
echo "Routes updated!";
