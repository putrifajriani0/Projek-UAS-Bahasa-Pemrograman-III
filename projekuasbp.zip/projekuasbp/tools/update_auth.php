<?php
$file = 'app/Controllers/Auth.php';
$content = file_get_contents($file);

$newMethod = '    public function welcome()
    {
        if (session()->get("user_id")) {
            $role = session()->get("role");
            if ($role === "admin") {
                return redirect()->to("/admin/dashboard");
            }
            return redirect()->to("/voting");
        }
        return view("auth/welcome");
    }

';

$content = str_replace('    public function index()', $newMethod . '    public function index()', $content);

// Also update logout
$content = str_replace(
    'return redirect()->to(\'/auth/login\')->with(\'success\', \'Anda berhasil logout!\');',
    'return redirect()->to(\'/\')->with(\'success\', \'Anda berhasil logout!\');',
    $content
);

file_put_contents($file, $content);
echo "Done!";
