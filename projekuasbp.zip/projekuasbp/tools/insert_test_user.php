<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'db_e_voting';
$port = 3306;

$mysqli = new mysqli($host, $user, $pass, $db, $port);
if ($mysqli->connect_errno) {
    echo "Connect failed: " . $mysqli->connect_error . PHP_EOL;
    exit(1);
}

$username = 'testvoter'.rand(1000,9999);
$email = $username.'@example.test';
$password_plain = 'password123';
$password_hash = password_hash($password_plain, PASSWORD_BCRYPT);
$full_name = 'Test Voter';
$nik = strval(rand(1000000000000000, 9999999999999999));

$stmt = $mysqli->prepare('INSERT INTO users (username,email,password,full_name,nik,role,has_voted) VALUES (?,?,?,?,?,"voter",0)');
$stmt->bind_param('sssss', $username, $email, $password_hash, $full_name, $nik);
if ($stmt->execute()) {
    echo "Inserted user: $username with password $password_plain\n";
    $id = $stmt->insert_id;
    $res = $mysqli->query("SELECT * FROM users WHERE id = $id");
    $row = $res->fetch_assoc();
    echo json_encode($row, JSON_PRETTY_PRINT).PHP_EOL;
} else {
    echo "Insert failed: " . $stmt->error . PHP_EOL;
}

$mysqli->close();
