<?php
require __DIR__ . '/../vendor/autoload.php';

use App\Models\UserModel;

$model = new UserModel();

// Test 1: Register dengan valid data
echo "=== TEST 1: Register dengan valid data ===" . PHP_EOL;
$testUser = [
    'username' => 'testvoter' . uniqid(),
    'email' => 'testvoter' . uniqid() . '@test.local',
    'password' => 'password123',
    'full_name' => 'Test Voter',
    'nik' => '1234567890123456',
    'role' => 'voter'
];

$result = $model->register($testUser);
echo "Register result: " . ($result ? 'SUCCESS' : 'FAILED') . PHP_EOL;

if ($result) {
    echo "Registered user: " . $testUser['username'] . PHP_EOL;
    
    // Test 2: Login dengan credential yang benar
    echo PHP_EOL . "=== TEST 2: Login dengan credential benar ===" . PHP_EOL;
    $user = $model->login($testUser['username'], 'password123');
    if ($user) {
        echo "Login SUCCESS" . PHP_EOL;
        echo "User data:" . PHP_EOL;
        echo "  ID: " . $user['id'] . PHP_EOL;
        echo "  Username: " . $user['username'] . PHP_EOL;
        echo "  Email: " . $user['email'] . PHP_EOL;
        echo "  Role: " . $user['role'] . PHP_EOL;
        echo "  Has Voted: " . $user['has_voted'] . PHP_EOL;
    } else {
        echo "Login FAILED" . PHP_EOL;
    }
    
    // Test 3: Login dengan password yang salah
    echo PHP_EOL . "=== TEST 3: Login dengan password salah ===" . PHP_EOL;
    $user = $model->login($testUser['username'], 'wrongpassword');
    echo "Login result: " . ($user ? 'SUCCESS (UNEXPECTED)' : 'FAILED (EXPECTED)') . PHP_EOL;
} else {
    echo "Register failed. Errors:" . PHP_EOL;
    echo json_encode($model->errors(), JSON_PRETTY_PRINT) . PHP_EOL;
}

echo PHP_EOL . "=== TEST SELESAI ===" . PHP_EOL;
