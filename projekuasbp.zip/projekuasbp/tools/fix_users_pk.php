<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'db_e_voting';
$port = 3306;

$mysqli = new mysqli($host, $user, $pass, $db, $port);
if ($mysqli->connect_errno) {
    echo "Connect failed: " . $mysqli->connect_error . PHP_EOL;
    exit(1);
}

// Backup
if (!$mysqli->query("DROP TABLE IF EXISTS users_backup")) {
    echo "Warning dropping backup: " . $mysqli->error . PHP_EOL;
}
if (!$mysqli->query("CREATE TABLE users_backup LIKE users")) {
    echo "Create backup table failed: " . $mysqli->error . PHP_EOL;
    exit(1);
}
if (!$mysqli->query("INSERT INTO users_backup SELECT * FROM users")) {
    echo "Insert backup data failed: " . $mysqli->error . PHP_EOL;
    exit(1);
}

// Try add primary key on id
$q = "ALTER TABLE users ADD PRIMARY KEY (id)";
if ($mysqli->query($q)) {
    echo "OK: Added primary key on id" . PHP_EOL;
} else {
    echo "Add primary key failed: " . $mysqli->error . PHP_EOL;
    // Try alternate approach: drop unique index on id then add primary key in single alter
    $alt = "ALTER TABLE users DROP INDEX id, ADD PRIMARY KEY (id)";
    if ($mysqli->query($alt)) {
        echo "OK: Dropped unique id index and added primary key" . PHP_EOL;
    } else {
        echo "Alternate approach failed: " . $mysqli->error . PHP_EOL;
        exit(1);
    }
}

echo "Done." . PHP_EOL;
$mysqli->close();
