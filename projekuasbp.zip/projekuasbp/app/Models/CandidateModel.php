<?php

namespace App\Models;

use CodeIgniter\Model;

class CandidateModel extends Model
{
    protected $table         = 'candidates';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['name', 'description', 'photo', 'vision', 'mission', 'vote_count', 'status'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $dateFormat    = 'datetime';

    protected $validationRules = [
        'name'        => 'required|string',
        'description' => 'string',
        'vision'      => 'string',
        'mission'     => 'string',
    ];

    public function getActiveCandidates()
    {
        return $this->where('status', 'active')->findAll();
    }

    public function incrementVoteCount($candidateId)
    {
        $candidate = $this->find($candidateId);
        if ($candidate) {
            $newCount = $candidate['vote_count'] + 1;
            $this->update($candidateId, ['vote_count' => $newCount]);
            return true;
        }
        return false;
    }

    public function getResults()
    {
        return $this->where('status', 'active')
                    ->orderBy('vote_count', 'DESC')
                    ->findAll();
    }
}
