<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table         = 'users';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['username', 'email', 'password', 'full_name', 'nik', 'role', 'has_voted'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $dateFormat    = 'datetime';

    protected $validationRules = [
        'username'  => 'required|alpha_numeric|is_unique[users.username]',
        'email'     => 'required|valid_email|is_unique[users.email]',
        'password'  => 'required|min_length[6]',
        'full_name' => 'required|string',
        'nik'       => 'required|numeric|is_unique[users.nik]',
    ];

    protected $validationMessages = [
        'username' => [
            'is_unique' => 'Username sudah terdaftar',
        ],
        'email' => [
            'is_unique' => 'Email sudah terdaftar',
        ],
        'nik' => [
            'is_unique' => 'NIK sudah terdaftar',
        ],
    ];

    public function register($data)
    {
        // Ensure all required fields are present
        if (empty($data['username']) || empty($data['email']) || empty($data['password']) || empty($data['full_name']) || empty($data['nik'])) {
            log_message('error', 'Register: missing required fields');
            return false;
        }
        
        $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
        $data['role'] = $data['role'] ?? 'voter';
        $data['has_voted'] = 0;
        
        $result = $this->insert($data);
        if (!$result) {
            log_message('error', 'Register: insert failed - ' . json_encode($this->errors()));
        }
        return $result;
    }

    public function login($username, $password)
    {
        if (empty($username) || empty($password)) {
            log_message('warning', 'Login: empty username or password');
            return false;
        }
        
        $user = $this->where('username', $username)->first();
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        
        if (!$user) {
            log_message('warning', 'Login: user not found - ' . $username);
        } else {
            log_message('warning', 'Login: password mismatch for user - ' . $username);
        }
        return false;
    }

    public function hasVoted($userId)
    {
        return $this->where('id', $userId)->first()['has_voted'] ?? false;
    }

    public function markAsVoted($userId)
    {
        return $this->update($userId, ['has_voted' => true]);
    }
}
