<?php

namespace App\Models;

use CodeIgniter\Model;

class VoteModel extends Model
{
    protected $table         = 'votes';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useSoftDeletes = false;
    protected $protectFields = true;
    protected $allowedFields = ['user_id', 'candidate_id'];
    // Disable automatic timestamps to remain compatible with existing DB schema
    protected $useTimestamps = false;
    protected $dateFormat    = 'datetime';

    protected $validationRules = [
        'user_id'      => 'required|numeric',
        'candidate_id' => 'required|numeric',
    ];

    public function castVote($userId, $candidateId)
    {
        return $this->insert([
            'user_id'      => $userId,
            'candidate_id' => $candidateId,
        ]);
    }

    public function userHasVoted($userId)
    {
        return $this->where('user_id', $userId)->first() !== null;
    }

    public function getVotesByCandidate($candidateId)
    {
        return $this->where('candidate_id', $candidateId)->countAllResults();
    }

    /**
     * Get recent votes with joined user and candidate data.
     * Returns array of rows: id, user_id, candidate_id, created_at, username, full_name, candidate_name
     */
    public function getVotesWithUserAndCandidate($limit = null)
    {
        $builder = $this->db->table($this->table . ' v')
            ->select('v.id, v.user_id, v.candidate_id, v.created_at, u.username, u.full_name, c.name AS candidate_name')
            ->join('users u', 'u.id = v.user_id')
            ->join('candidates c', 'c.id = v.candidate_id')
            ->orderBy('v.created_at', 'DESC');

        if ($limit) {
            $builder->limit((int) $limit);
        }

        return $builder->get()->getResultArray();
    }

    /**
     * Get vote counts grouped by candidate (candidate id + name + votes)
     */
    public function getVoteCountsByCandidate()
    {
        $builder = $this->db->table($this->table . ' v')
            ->select('c.id AS candidate_id, c.name AS candidate_name, COUNT(v.id) AS votes')
            ->join('candidates c', 'c.id = v.candidate_id')
            ->groupBy('c.id, c.name')
            ->orderBy('votes', 'DESC');

        return $builder->get()->getResultArray();
    }
}
