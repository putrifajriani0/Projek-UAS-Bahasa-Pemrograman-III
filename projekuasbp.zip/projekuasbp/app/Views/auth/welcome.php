<?php $title = 'E-Voting OSIM MAN 1 AGAM' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div style="display: flex; align-items: center; justify-content: center; min-height: 70vh;">
    <div class="welcome-container">
        <div class="icon">🗳️</div>
        <h1>E-VOTING OSIM</h1>
        <h3 style="color: #667eea; margin-bottom: 20px;">MAN 1 AGAM</h3>
        <p>Sistem Pemilihan Umum Organisasi Siswa Intra Madrasah</p>
        
        <div style="margin: 40px 0;">
            <p style="margin-bottom: 20px; font-weight: bold; color: #764ba2;">Selamat datang! Pilih aksi Anda:</p>
            <a href="<?= base_url('auth/login') ?>" class="btn btn-welcome btn-login">🔑 LOGIN</a>
            <a href="<?= base_url('auth/register') ?>" class="btn btn-welcome btn-register">📝 DAFTAR</a>
        </div>

        <div class="features">
            <div class="feature">
                <div class="feature-icon">✅</div>
                <div class="feature-title">Aman</div>
                <div class="feature-desc">Enkripsi password terjamin</div>
            </div>
            <div class="feature">
                <div class="feature-icon">🔒</div>
                <div class="feature-title">Terpercaya</div>
                <div class="feature-desc">Hanya 1 suara per pemilih</div>
            </div>
            <div class="feature">
                <div class="feature-icon">⚡</div>
                <div class="feature-title">Cepat</div>
                <div class="feature-desc">Proses voting instant</div>
            </div>
            <div class="feature">
                <div class="feature-icon">📊</div>
                <div class="feature-title">Transparan</div>
                <div class="feature-desc">Hasil voting real-time</div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<style>
    .welcome-container {
        background: white;
        border-radius: 15px;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        padding: 50px;
        max-width: 600px;
        width: 100%;
        text-align: center;
    }
    .welcome-container h1 {
        color: #333;
        margin-bottom: 15px;
        font-weight: bold;
        font-size: 2.5em;
    }
    .welcome-container p {
        color: #666;
        font-size: 1.1em;
        margin-bottom: 40px;
    }
    .btn-welcome {
        font-size: 1.1em;
        padding: 12px 40px;
        border-radius: 8px;
        font-weight: bold;
        transition: all 0.3s;
        margin: 10px;
    }
    .btn-login {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
    }
    .btn-login:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        color: white;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }
    .btn-register {
        background: white;
        color: #667eea;
        border: 2px solid #667eea;
    }
    .btn-register:hover {
        background: #f0f0ff;
        color: #667eea;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(102, 126, 234, 0.2);
    }
    .icon {
        font-size: 4em;
        margin-bottom: 20px;
    }
    .features {
        text-align: left;
        margin-top: 40px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .feature {
        padding: 15px;
        background: #f8f9fa;
        border-radius: 8px;
        border-left: 4px solid #667eea;
    }
    .feature-icon {
        font-size: 2em;
        margin-bottom: 10px;
    }
    .feature-title {
        font-weight: bold;
        color: #333;
        margin-bottom: 5px;
    }
    .feature-desc {
        font-size: 0.9em;
        color: #666;
    }
</style>
<?= $this->endSection() ?>
