<?php $title = 'Login - E-Voting' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-center align-items-center" style="min-height:60vh">
    <div class="card p-4" style="max-width:420px; width:100%">
        <h4 class="card-title text-center mb-3">🗳️ Masuk</h4>

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <form method="POST" action="<?= base_url('auth/login') ?>" id="loginForm">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <div class="input-group">
                    <input type="password" class="form-control" id="password" name="password" required>
                    <button class="btn btn-outline-secondary" type="button" id="togglePasswordBtn" aria-label="Lihat password" onclick="togglePassword('password','togglePasswordBtn')">👁</button>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100">LOGIN</button>
        </form>

        <div class="text-center mt-3">
            Belum punya akun? <a href="<?= base_url('auth/register') ?>">Daftar sekarang</a>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
function togglePassword(inputId, btnId){
    var input = document.getElementById(inputId);
    if(!input) return;
    input.type = input.type === 'password' ? 'text' : 'password';
}

// Simple client-side check (optional)
document.getElementById('loginForm')?.addEventListener('submit', function(e){
    var u = document.getElementById('username').value.trim();
    var p = document.getElementById('password').value.trim();
    if(!u || !p){
        e.preventDefault();
        alert('Username dan password harus diisi');
    }
});
</script>
<?= $this->endSection() ?>
