<?php $title = 'Register - E-Voting' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-center align-items-center" style="min-height:60vh">
    <div class="card p-4" style="max-width:600px; width:100%">
        <h4 class="card-title text-center mb-3">📝 Daftar Akun</h4>

        <?php
            $flashErrors = session()->getFlashdata('errors');
            $flashError = session()->getFlashdata('error');
            $errorsList = $flashErrors ?? (isset($errors) ? $errors : null);
        ?>

        <?php if (!empty($flashError)): ?>
            <div class="alert alert-danger"><?= esc($flashError) ?></div>
        <?php endif; ?>

        <?php if (!empty($errorsList)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errorsList as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?= base_url('auth/registerProcess') ?>" id="registerForm">
            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3 col-md-6">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
            </div>

            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="full_name" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                </div>
                <div class="mb-3 col-md-6">
                    <label for="nik" class="form-label">NIK (16 digit)</label>
                    <input type="text" class="form-control" id="nik" name="nik" minlength="16" maxlength="16" required>
                </div>
            </div>

            <div class="row">
                <div class="mb-3 col-md-6">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="password" name="password" required>
                        <button class="btn btn-outline-secondary" type="button" id="toggleRegPass" aria-label="Lihat password" onclick="togglePassword('password')">👁</button>
                    </div>
                </div>
                <div class="mb-3 col-md-6">
                    <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                    <div class="input-group">
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        <button class="btn btn-outline-secondary" type="button" id="toggleRegConfirm" aria-label="Lihat konfirmasi password" onclick="togglePassword('confirm_password')">👁</button>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary w-100">DAFTAR</button>
        </form>

        <div class="text-center mt-3">
            Sudah punya akun? <a href="<?= base_url('auth/login') ?>">Login di sini</a>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
function togglePassword(id){
    var e=document.getElementById(id); if(!e) return; e.type = e.type === 'password' ? 'text' : 'password';
}

document.getElementById('registerForm')?.addEventListener('submit', function(e){
    var p = document.getElementById('password').value || '';
    var c = document.getElementById('confirm_password').value || '';
    if(p !== c){ e.preventDefault(); alert('Password dan konfirmasi harus sama'); }
});
</script>
<?= $this->endSection() ?>
