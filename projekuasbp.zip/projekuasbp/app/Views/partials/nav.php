<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?= base_url('/') ?>">🗳️ E-Voting OSIM MAN 1 AGAM</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item"><a class="nav-link" href="<?= base_url('/') ?>">Home</a></li>
        <?php if (session()->get('user_id')): ?>
          <?php if (session()->get('role') === 'admin'): ?>
            <li class="nav-item"><a class="nav-link" href="<?= base_url('admin/dashboard') ?>">Admin</a></li>
          <?php else: ?>
            <li class="nav-item"><a class="nav-link" href="<?= base_url('voting') ?>">Voting</a></li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>

      <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <?php if (session()->get('user_id')): ?>
          <li class="nav-item"><a class="nav-link" href="#">Halo, <?= esc(session()->get('full_name')) ?></a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url('auth/logout') ?>">Logout</a></li>
        <?php else: ?>
          <li class="nav-item"><a class="nav-link" href="<?= base_url('auth/login') ?>">Login</a></li>
          <li class="nav-item"><a class="nav-link" href="<?= base_url('auth/register') ?>">Register</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
