<?php $title = 'Hasil Voting - E-Voting OSIM MAN 1 AGAM' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="container-results">
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success" role="alert">
                    ✓ <?= session()->getFlashdata('success') ?>
                </div>
            <?php endif; ?>
            
            <div class="header-results">
                <h2>📊 HASIL SEMENTARA PEMILIHAN</h2>
                <p class="text-muted mb-0">Data ini akan terus diperbarui seiring dengan voting yang berlangsung.</p>
            </div>
            
            <div class="row">
                <div class="col-md-8">
                    <?php 
                    // Hitung total suara
                    $totalVotes = 0;
                    foreach ($candidates as $candidate) {
                        $totalVotes += (int)$candidate['vote_count'];
                    }
                    
                    // Urutkan kandidat berdasarkan jumlah suara (tertinggi ke terendah)
                    $sortedCandidates = $candidates;
                    usort($sortedCandidates, function($a, $b) {
                        return (int)$b['vote_count'] - (int)$a['vote_count'];
                    });
                    
                    $ranking = 1; 
                    foreach ($sortedCandidates as $candidate): 
                        // Hitung persentase
                        $voteCount = (int)$candidate['vote_count'];
                        $percentage = ($totalVotes > 0) ? ($voteCount / $totalVotes * 100) : 0;
                    ?>
                        <div class="card-result">
                            <div class="row align-items-center">
                                <div class="col-md-1">
                                    <div class="result-ranking">#<?= $ranking++ ?></div>
                                </div>
                                <div class="col-md-1">
                                    <?php
                                    // Cek foto kandidat
                                    if (!empty($candidate['photo']) && file_exists(FCPATH . $candidate['photo'])) {
                                        $photoUrl = base_url($candidate['photo']);
                                        echo '<img src="' . $photoUrl . '" alt="' . esc($candidate['name']) . '" class="candidate-photo">';
                                    } else {
                                        // Fallback ke inisial nama
                                        $initials = substr($candidate['name'], 0, 2);
                                        echo '<div class="no-photo">' . strtoupper($initials) . '</div>';
                                    }
                                    ?>
                                </div>
                                <div class="col-md-6">
                                    <h5><?= esc($candidate['name']) ?></h5>
                                    <div class="progress">
                                        <div class="progress-bar" role="progressbar"
                                             style="width: <?= round($percentage, 2) ?>%; background-color: #667eea;"
                                             aria-valuenow="<?= $voteCount ?>"
                                             aria-valuemin="0"
                                             aria-valuemax="<?= $totalVotes ?>">
                                            <span class="progress-text" style="color: #000; font-weight: bold;">
                                                <?= round($percentage, 2) ?>%
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 text-end">
                                    <span class="result-votes"><?= number_format($voteCount, 0, ',', '.') ?> suara</span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="col-md-4">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Statistik</h5>
            <div style="position: relative; height:180px; margin-bottom: 20px;">
                <canvas id="participationChart"></canvas>
            </div>
            <div class="mt-3">
                <p class="mb-1"><strong>Total Pemilih:</strong> <?= number_format($totalVoters, 0, ',', '.') ?></p>
                <p class="mb-1"><strong>Sudah Voting:</strong> <?= number_format($totalVotes, 0, ',', '.') ?></p>
                
            </div>
        </div>
    </div>
</div>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-12 text-center">
                    <?php if (session()->get('role') === 'admin'): ?>
                        <a href="<?= base_url('admin/dashboard') ?>" class="btn btn-outline-secondary btn-lg me-2">⟵ KEMBALI KE DASHBOARD</a>
                    <?php endif; ?>
                    <a href="<?= base_url('auth/logout') ?>" class="btn btn-logout btn-lg">LOGOUT</a>
                </div>
            </div>
        </div>
    </div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<style>
    .container-results {
        padding: 30px 0;
    }
    .card-result {
        background: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border-left: 5px solid #667eea;
    }
    .result-ranking {
        font-size: 24px;
        font-weight: bold;
        color: #667eea;
    }
    .result-votes {
        font-size: 20px;
        color: #764ba2;
        font-weight: bold;
    }
    .progress {
        height: 25px;
    }
    .btn-logout {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        color: white;
        font-weight: bold;
    }
    .btn-logout:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        color: white;
    }
    .candidate-photo {
        width: 56px;
        height: 56px;
        object-fit: cover;
        border-radius: 6px;
    }
    .no-photo {
        width: 56px;
        height: 56px;
        background: linear-gradient(45deg, #667eea, #764ba2);
        border-radius: 6px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 20px;
    }
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<script>
    // Prepare data for chart
    const candidateNames = [
        <?php foreach ($sortedCandidates as $candidate): ?>
            '<?= addslashes($candidate['name']) ?>',
        <?php endforeach; ?>
    ];
    
    const candidateVotes = [
        <?php foreach ($sortedCandidates as $candidate): ?>
            <?= (int)$candidate['vote_count'] ?>,
        <?php endforeach; ?>
    ];
    
    // Color palette
    const colors = [
        '#667eea', '#764ba2', '#f093fb', '#4facfe', '#43e97b',
        '#fa709a', '#f6d365', '#a8edea', '#fed6e3', '#a8edea'
    ];
    
    // Participation Chart
    const ctxPart = document.getElementById('participationChart').getContext('2d');
    const participationChart = new Chart(ctxPart, {
        type: 'doughnut',
        data: {
            labels: ['Sudah Voting', 'Belum Voting'],
            datasets: [{
                data: [<?= (int)$totalVotes ?>, <?= (int)($totalVoters - $totalVotes) ?>],
                backgroundColor: ['#667eea', '#e8eaf6'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '75%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        font: { size: 12, weight: '500' },
                        boxWidth: 14,
                        padding: 15,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.label + ': ' + context.parsed;
                        }
                    }
                }
            }
        }
    });
</script>
<?= $this->endSection() ?>