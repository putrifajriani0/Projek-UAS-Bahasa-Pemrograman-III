<?php $title = 'Voting - E-Voting MAN 1 AGAM' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="container-voting">
    <div class="container">
        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger" role="alert"><?= session()->getFlashdata('error') ?></div>
        <?php endif; ?>

        <form method="POST" action="<?= base_url('voting/cast') ?>" id="votingForm">
            <div class="row" id="candidatesContainer">
                <?php 
                    $photoIndex = 1;
                    foreach ($candidates as $candidate): 
                        $dbPhoto = !empty($candidate['photo']) ? $candidate['photo'] : null;
                        $staticPhoto = 'uploads/kandidat' . $photoIndex . '.jpg';
                        $photoIndex++;
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card card-candidate h-100" onclick="selectCandidate(<?= (int)$candidate['id'] ?>)">
                        <?php if ($dbPhoto && file_exists(FCPATH . $dbPhoto)): ?>
                            <img src="<?= base_url($dbPhoto) ?>" alt="Foto <?= esc($candidate['name']) ?>" class="candidate-photo">
                        <?php elseif (file_exists(FCPATH . $staticPhoto)): ?>
                            <img src="<?= base_url($staticPhoto) ?>" alt="Foto <?= esc($candidate['name']) ?>" class="candidate-photo">
                        <?php else: ?>
                            <div class="no-photo"><?= substr(trim($candidate['name']), 0, 1) ?></div>
                        <?php endif; ?>

                        <div class="card-body">
                            <h5 class="card-title"><?= esc($candidate['name']) ?></h5>
                            <p class="card-text small text-muted"><?php if (!empty($candidate['description'])): ?><?= esc(substr($candidate['description'], 0, 100)) ?><?php else: ?><span class="text-muted fst-italic">Tidak ada deskripsi</span><?php endif; ?></p>

                            <?php if (!empty($candidate['vision'])): ?><p class="card-text"><small><strong>Visi:</strong> <?= esc(substr($candidate['vision'], 0, 80)) ?></small></p><?php endif; ?>
                            <?php if (!empty($candidate['mission'])): ?><p class="card-text"><small><strong>Misi:</strong> <?= esc(substr($candidate['mission'], 0, 200)) ?></small></p><?php endif; ?>

                            <input type="radio" name="candidate_id" value="<?= (int)$candidate['id'] ?>" id="candidate_<?= (int)$candidate['id'] ?>" required style="margin-top:10px;">
                            <label for="candidate_<?= (int)$candidate['id'] ?>" style="cursor:pointer; margin-left:5px;">Select Candidate</label>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="row mt-4">
                <div class="col-md-12 text-center">
                    <button type="submit" class="btn btn-primary btn-lg">✓ KONFIRMASI SUARA SAYA</button>
            
                </div>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<style>
    .container-voting { padding: 20px 0; }
    .card-candidate {
        cursor: pointer;
        transition: all 0.3s ease;
        border: 2px solid #e0e0e0;
        border-radius: 10px;
        position: relative;
    }
    .card-candidate:hover {
        border-color: #667eea;
        box-shadow: 0 5px 20px rgba(102, 126, 234, 0.2);
        transform: translateY(-2px);
    }
    .card-candidate.selected {
        border-color: #667eea;
        background-color: #f0f0ff;
        box-shadow: 0 5px 20px rgba(102, 126, 234, 0.3);
    }
    .card-candidate.selected::before {
        content: '✓';
        position: absolute;
        top: 10px;
        right: 10px;
        background: #667eea;
        color: white;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 18px;
    }
    .candidate-photo {
        width: 100%;
        height: 350px;
        object-fit: cover;
        border-radius: 10px 10px 0 0;
    }
    .no-photo {
        width: 100%;
        height: 200px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px 10px 0 0;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 80px;
        font-weight: bold;
    }
    .card-candidate .card-title {
        color: #333;
        font-weight: bold;
        margin-top: 10px;
    }
    .card-candidate .card-text {
        color: #666;
        font-size: 0.9em;
    }
</style>

<script>
function selectCandidate(id){
    document.querySelectorAll('.card-candidate').forEach(card => card.classList.remove('selected'));
    var radio = document.querySelector('#candidate_'+id);
    if(radio){ radio.checked = true; radio.closest('.card-candidate').classList.add('selected'); }
}

// Form submission validation
document.getElementById('votingForm')?.addEventListener('submit', function(e) {
    const selected = document.querySelector('input[name="candidate_id"]:checked');
    if (!selected) {
        e.preventDefault();
        alert('Silakan pilih kandidat terlebih dahulu!');
        return false;
    }
});

<?= $this->endSection() ?>