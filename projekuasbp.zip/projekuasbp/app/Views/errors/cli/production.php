<?php

include __DIR__ . '/error_exception.php';
