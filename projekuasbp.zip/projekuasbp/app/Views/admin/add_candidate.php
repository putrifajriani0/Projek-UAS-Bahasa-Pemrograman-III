<?php $title = 'Tambah Kandidat - Admin' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row">
    <div class="col-md-3">
        <div class="list-group">
            <a href="<?= base_url('admin/dashboard') ?>" class="list-group-item list-group-item-action">📊 Dashboard</a>
            <a href="<?= base_url('admin/candidates') ?>" class="list-group-item list-group-item-action active">👥 Kelola Kandidat</a>
            <a href="<?= base_url('admin/voters') ?>" class="list-group-item list-group-item-action">🗳️ Daftar Pemilih</a>
        </div>
    </div>
    <div class="col-md-9">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">➕ Tambah Kandidat</h4>

                <?php if (session()->getFlashdata('errors')): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                                <li><?= esc($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?= base_url('admin/saveCandidateProcess') ?>" enctype="multipart/form-data" id="addCandidateForm">
                    <?= csrf_field() ?>
                    
                    <div class="mb-3">
                        <label for="name" class="form-label">Nama Kandidat *</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= old('name') ?>" required>
                        <small class="form-text text-muted">Nama lengkap kandidat</small>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="description" name="description" rows="3"><?= old('description') ?></textarea>
                        <small class="form-text text-muted">Profil singkat kandidat (opsional)</small>
                    </div>

                    <div class="mb-3">
                        <label for="vision" class="form-label">Visi</label>
                        <textarea class="form-control" id="vision" name="vision" rows="2"><?= old('vision') ?></textarea>
                        <small class="form-text text-muted">Visi kandidat jika terpilih</small>
                    </div>

                    <div class="mb-3">
                        <label for="mission" class="form-label">Misi</label>
                        <textarea class="form-control" id="mission" name="mission" rows="2"><?= old('mission') ?></textarea>
                        <small class="form-text text-muted">Misi kandidat jika terpilih</small>
                    </div>

                    <div class="mb-3">
                        <label for="photo" class="form-label">Foto Kandidat</label>
                        <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                        <small class="form-text text-muted">Format: JPG, PNG, GIF. Ukuran maks: 5MB</small>
                    </div>

                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">✓ Simpan Kandidat</button>
                        <a href="<?= base_url('admin/candidates') ?>" class="btn btn-outline-secondary">⟵ Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
document.getElementById('addCandidateForm')?.addEventListener('submit', function(e){
    var n = document.getElementById('name').value.trim();
    if(!n){ e.preventDefault(); alert('Nama kandidat harus diisi'); }
});
</script>
<?= $this->endSection() ?>