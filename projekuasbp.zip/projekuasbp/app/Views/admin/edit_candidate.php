<?php $title = 'Edit Kandidat - Admin' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="container mt-4">
    <h2 class="mb-4">✏️ Edit Kandidat</h2>
    
    <div class="form-container">
        <?php if (isset($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" action="<?= base_url('admin/updateCandidateProcess/' . $candidate['id']) ?>" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="name" class="form-label">Nama Kandidat *</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?= $candidate['name'] ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label">Deskripsi Singkat</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?= $candidate['description'] ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="vision" class="form-label">Visi</label>
                            <textarea class="form-control" id="vision" name="vision" rows="3"><?= $candidate['vision'] ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label for="mission" class="form-label">Misi</label>
                            <textarea class="form-control" id="mission" name="mission" rows="3"><?= $candidate['mission'] ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Foto Saat Ini</label>
                            <?php if ($candidate['photo']): ?>
                                <br>
                                <img src="<?= base_url($candidate['photo']) ?>" alt="<?= $candidate['name'] ?>" class="candidate-photo-preview">
                            <?php else: ?>
                                <p class="text-muted">Belum ada foto</p>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <label for="photo" class="form-label">Ganti Foto Kandidat</label>
                            <input type="file" class="form-control" id="photo" name="photo" accept="image/*">
                            <small class="text-muted">Format: JPG, PNG, GIF. Ukuran maksimal: 5MB</small>
                        </div>
                        
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-submit">💾 Update Kandidat</button>
                            <a href="<?= base_url('admin/candidates') ?>" class="btn btn-outline-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<style>
    .form-container {
        background: white;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    .btn-submit {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border: none;
        color: white;
        font-weight: bold;
    }
    .btn-submit:hover {
        background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        color: white;
    }
    .form-control:focus {
        border-color: #667eea;
        box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
    }
    .candidate-photo-preview {
        width: 150px;
        height: 150px;
        object-fit: cover;
        border-radius: 5px;
        margin: 15px 0;
    }
</style>

<script>
    document.querySelector('form').addEventListener('submit', function(e) {
        const name = document.getElementById('name').value.trim();
        if (!name) {
            e.preventDefault();
            alert('Nama kandidat harus diisi!');
            return false;
        }
    });
</script>
<?= $this->endSection() ?>
