<?php $title = 'Daftar Pemilih - Admin' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="container mt-4">
    <h2 class="mb-4">🗳️ Daftar Pemilih</h2>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Nama Lengkap</th>
                            <th>NIK</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($voters as $voter): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= esc($voter['username']) ?></td>
                                <td><?= esc($voter['email']) ?></td>
                                <td><?= esc($voter['full_name']) ?></td>
                                <td><?= esc($voter['nik']) ?></td>
                                <td>
                                    <?php if ($voter['has_voted']): ?>
                                        <span class="badge bg-success">✓ Sudah Voting</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">⏳ Belum Voting</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (empty($voters)): ?>
                <div class="alert alert-info">Belum ada pemilih yang terdaftar.</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Dapat menambahkan fitur export Excel atau print di sini
    console.log('Daftar pemilih loaded');
</script>
<?= $this->endSection() ?>
