<?php $title = 'Admin Dashboard' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row">
    <div class="col-md-3">
        <div class="list-group">
            <a href="<?= base_url('admin/dashboard') ?>" class="list-group-item list-group-item-action active">📊 Dashboard</a>
            <a href="<?= base_url('admin/candidates') ?>" class="list-group-item list-group-item-action">👥 Kelola Kandidat</a>
            <a href="<?= base_url('voting') ?>" class="list-group-item list-group-item-action">🔘 Voting</a>
            <a href="<?= base_url('admin/voters') ?>" class="list-group-item list-group-item-action">🗳️ Daftar Pemilih</a>
        </div>
    </div>
    <div class="col-md-9">
        <h4>📊 Dashboard Admin</h4>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Total Pemilih</div>
                    <div class="h4"><?= (int)$totalVoters ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Sudah Voting</div>
                    <div class="h4"><?= (int)$totalVotes ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Belum Voting</div>
                    <div class="h4"><?= (int)($totalVoters - $totalVotes) ?></div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card p-3">
                    <div class="text-muted small">Total Kandidat</div>
                    <div class="h4"><?= (int)$totalCandidates ?></div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-3"><div class="card-body"><h6>Hasil Voting</h6><canvas id="votingChart"></canvas></div></div>
            </div>
            <div class="col-md-6">
                <div class="card mb-3"><div class="card-body"><h6>Partisipasi</h6><canvas id="participationChart"></canvas></div></div>
            </div>
        </div>

        <div class="card mt-2"><div class="card-body">
            <h6>Peringkat Kandidat</h6>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead><tr><th>#</th><th>Nama</th><th>Suara</th><th>Persentase</th></tr></thead>
                    <tbody>
                        <?php $ranking = 1; $totalSuara = array_sum(array_column($candidates, 'vote_count')); ?>
                        <?php foreach ($candidates as $candidate): ?>
                            <tr>
                                <td><?= $ranking++ ?></td>
                                <td><?= esc($candidate['name']) ?></td>
                                <td><?= (int)$candidate['vote_count'] ?></td>
                                <td>
                                    <div class="progress"><div class="progress-bar" role="progressbar" style="width: <?= $totalSuara>0?(($candidate['vote_count']/$totalSuara)*100):0 ?>%;"><?= $totalSuara>0?round(($candidate['vote_count']/$totalSuara)*100,1):0 ?>%</div></div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div></div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
<script>
const labels = [<?= implode(',', array_map(function($c){return "'".addslashes($c['name'])."'";}, $candidates)) ?>];
const dataVotes = [<?= implode(',', array_map(function($c){return (int)$c['vote_count'];}, $candidates)) ?>];
const ctx1 = document.getElementById('votingChart')?.getContext('2d');
if(ctx1){ new Chart(ctx1, {type:'bar', data:{labels:labels,datasets:[{label:'Jumlah Suara',data:dataVotes,backgroundColor:'#667eea'}]}, options:{responsive:true}}); }

const ctx2 = document.getElementById('participationChart')?.getContext('2d');
if(ctx2){ new Chart(ctx2, {type:'doughnut', data:{labels:['Sudah Voting','Belum Voting'], datasets:[{data:[<?= (int)$totalVotes ?>, <?= (int)($totalVoters-$totalVotes) ?>], backgroundColor:['#667eea','#ddd']}]}, options:{responsive:true}}); }
</script>
<?= $this->endSection() ?>
