<?php $title = 'Kelola Kandidat - Admin' ?>
<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="row">
    <div class="col-md-3">
        <div class="list-group">
            <a href="<?= base_url('admin/dashboard') ?>" class="list-group-item list-group-item-action">📊 Dashboard</a>
            <a href="<?= base_url('admin/candidates') ?>" class="list-group-item list-group-item-action active">👥 Kelola Kandidat</a>
            <a href="<?= base_url('admin/voters') ?>" class="list-group-item list-group-item-action">🗳️ Daftar Pemilih</a>
            <a href="<?= base_url('admin/resetVoting') ?>" class="list-group-item list-group-item-action" onclick="return confirm('Yakin ingin mereset semua data voting?')">🔄 Reset Voting</a>
        </div>
    </div>
    <div class="col-md-9">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4>👥 Kelola Kandidat</h4>
            <a href="<?= base_url('admin/addCandidate') ?>" class="btn btn-primary">+ Tambah Kandidat</a>
        </div>

        <div id="adminMessages"></div>

        <div id="candidatesList">
            <!-- Server-side rendered fallback -->
            <?php foreach ($candidates as $candidate): ?>
                <div class="card mb-2">
                    <div class="card-body d-flex align-items-center">
                        <div class="me-3">
                            <?php if ($candidate['photo']): ?>
                                <img src="<?= base_url($candidate['photo']) ?>" alt="<?= esc($candidate['name']) ?>" style="width:80px;height:80px;object-fit:cover;border-radius:6px">
                            <?php else: ?>
                                <div style="width:80px;height:80px;background:#eee;border-radius:6px;display:flex;align-items:center;justify-content:center">No Photo</div>
                            <?php endif; ?>
                        </div>
                        <div class="flex-grow-1">
                            <h5 class="mb-1"><?= esc($candidate['name']) ?></h5>
                            <div class="text-muted small">Suara: <?= (int)$candidate['vote_count'] ?></div>
                        </div>
                        <div class="text-end">
                            <a href="<?= base_url('admin/editCandidate/'.$candidate['id']) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                            <a href="<?= base_url('admin/deleteCandidate/'.$candidate['id']) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
// Load fresh candidate list via AJAX
$(function(){
    $.getJSON('<?= base_url('admin/candidatesAjax') ?>').done(function(res){
        if(res.status !== 'ok') return;
        var html = '';
        var baseUrl = '<?= base_url() ?>';
        
        res.data.forEach(function(c){
            var photoHtml = '';
            if(c.photo){ 
                photoHtml = '<img src="'+c.photo+'" alt="'+c.name+'" style="width:80px;height:80px;object-fit:cover;border-radius:6px">'; 
            } else { 
                photoHtml = '<div style="width:80px;height:80px;background:#eee;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:12px;color:#999">No Photo</div>'; 
            }
            
            html += '<div class="card mb-2">';
            html += '<div class="card-body d-flex align-items-center">';
            html += '<div class="me-3">'+photoHtml+'</div>';
            html += '<div class="flex-grow-1"><h5 class="mb-1">'+c.name+'</h5><div class="text-muted small">Suara: '+(parseInt(c.vote_count)||0)+'</div></div>';
            html += '<div class="text-end">';
            html += '<a href="'+baseUrl+'admin/editCandidate/'+c.id+'" class="btn btn-sm btn-outline-primary">Edit</a> ';
            html += '<a href="'+baseUrl+'admin/deleteCandidate/'+c.id+'" class="btn btn-sm btn-outline-danger" onclick="return confirm(\'Yakin ingin menghapus?\')">Hapus</a>';
            html += '</div>';
            html += '</div></div>';
        });
        $('#candidatesList').html(html);
    }).fail(function(){
        $('#adminMessages').html('<div class="alert alert-warning">Gagal memuat data kandidat via AJAX.</div>');
    });
});
</script>
<?= $this->endSection() ?>
