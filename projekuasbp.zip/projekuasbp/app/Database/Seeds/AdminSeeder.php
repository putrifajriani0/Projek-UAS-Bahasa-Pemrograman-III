<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class AdminSeeder extends Seeder
{
    public function run()
    {
        $data = [
            'username'  => 'admin',
            'email'     => 'admin@example.com',
            'password'  => password_hash('admin123', PASSWORD_BCRYPT),
            'full_name' => 'Administrator',
            'nik'       => '0000000000000000',
            'role'      => 'admin',
            'has_voted' => false,
            'created_at'=> date('Y-m-d H:i:s'),
            'updated_at'=> date('Y-m-d H:i:s'),
        ];

        // Insert or update admin user
        $db      = \Config\Database::connect();
        $builder = $db->table('users');

        $existing = $builder->where('username', $data['username'])->get()->getRowArray();
        if ($existing) {
            // Update existing admin user
            $builder->where('username', $data['username'])->update($data);
        } else {
            // Insert new admin user
            $builder->insert($data);
        }
    }
}
