<?php

namespace App\Controllers;

use App\Models\CandidateModel;
use App\Models\VoteModel;
use App\Models\UserModel;

class Voting extends BaseController
{
    protected $candidateModel;
    protected $voteModel;
    protected $userModel;

    public function __construct()
    {
        $this->candidateModel = new CandidateModel();
        $this->voteModel = new VoteModel();
        $this->userModel = new UserModel();
    }

    public function index()
    {
        if (!session()->get('user_id')) {
            return redirect()->to('/auth/login');
        }

        $userId = session()->get('user_id');
        $hasVoted = session()->get('has_voted');

        if ($hasVoted) {
            return redirect()->to('/voting/results');
        }

        $candidates = $this->candidateModel->getActiveCandidates();

        return view('voting/voting', [
            'candidates' => $candidates,
        ]);
    }

    public function cast()
    {
        if (!session()->get('user_id')) {
            return redirect()->to('/auth/login');
        }

        $userId = session()->get('user_id');

        if (session()->get('has_voted')) {
            return redirect()->to('/voting/results')->with('error', 'Anda sudah melakukan voting!');
        }

        $candidateId = $this->request->getPost('candidate_id');

        if (!$candidateId) {
            return redirect()->back()->with('error', 'Pilih kandidat terlebih dahulu!');
        }

        if ($this->voteModel->castVote($userId, $candidateId)) {
            $this->candidateModel->incrementVoteCount($candidateId);
            $this->userModel->markAsVoted($userId);
            session()->set('has_voted', true);
            return redirect()->to('/voting/results')->with('success', 'Suara Anda berhasil direkam!');
        } else {
            return redirect()->back()->with('error', 'Gagal merekam suara!');
        }
    }

    public function results()
    {
        if (!session()->get('user_id')) {
            return redirect()->to('/auth/login');
        }

        $candidates = $this->candidateModel->getResults();
        
        // Hitung total pemilih
        $totalVoters = $this->userModel->countAllResults();
        
        // Hitung total suara
        $totalVotes = 0;
        foreach ($candidates as $candidate) {
            $totalVotes += (int)$candidate['vote_count'];
        }

        return view('voting/results', [
            'candidates' => $candidates,
            'totalVoters' => $totalVoters,
            'totalVotes' => $totalVotes,
        ]);
    }
}
