<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\CandidateModel;

class Admin extends BaseController
{
    protected $userModel;
    protected $candidateModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->candidateModel = new CandidateModel();
    }

    private function checkAdmin()
    {
        if (!session()->get('user_id') || session()->get('role') !== 'admin') {
            log_message('error', 'Access denied to admin area. User ID: ' . session()->get('user_id') . ', Role: ' . session()->get('role'));
            return redirect()->to('/auth/login');
        }
    }

    public function dashboard()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $totalVoters = $this->userModel->countAllResults();
        $totalCandidates = $this->candidateModel->countAllResults();
        $totalVotes = $this->userModel->where('has_voted', true)->countAllResults();
        $candidates = $this->candidateModel->getResults();

        return view('admin/dashboard', [
            'totalVoters'     => $totalVoters,
            'totalCandidates' => $totalCandidates,
            'totalVotes'      => $totalVotes,
            'candidates'      => $candidates,
        ]);
    }

    public function candidates()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $candidates = $this->candidateModel->findAll();

        return view('admin/candidates', [
            'candidates' => $candidates,
        ]);
    }

    public function candidatesAjax()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $candidates = $this->candidateModel->findAll();
        
        // Add base_url() to photo paths for AJAX response
        foreach ($candidates as &$candidate) {
            if (!empty($candidate['photo'])) {
                $candidate['photo'] = base_url($candidate['photo']);
            }
        }

        // Return JSON for AJAX consumption
        return $this->response->setJSON(['status' => 'ok', 'data' => $candidates]);
    }

    public function addCandidate()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        return view('admin/add_candidate');
    }

    public function saveCandidateProcess()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $rules = [
            'name'        => 'required|string',
            'description' => 'string',
            'vision'      => 'string',
            'mission'     => 'string',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name'        => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'vision'      => $this->request->getPost('vision'),
            'mission'     => $this->request->getPost('mission'),
            'status'      => 'active',
        ];

        // Handle photo upload with validation
        $photo = $this->request->getFile('photo');
        if ($photo && $photo->isValid() && !$photo->hasMoved()) {
            $allowedMime = ['image/jpeg', 'image/png', 'image/gif'];
            $maxSize = 5 * 1024 * 1024; // 5MB

            if (!in_array($photo->getClientMimeType(), $allowedMime)) {
                return redirect()->back()->withInput()->with('error', 'Format foto tidak didukung. Hanya JPG, PNG, GIF.');
            }

            if ($photo->getSize() > $maxSize) {
                return redirect()->back()->withInput()->with('error', 'Ukuran foto maksimal 5MB.');
            }

            $newName = $photo->getRandomName();
            $photo->move(ROOTPATH . 'public/uploads/', $newName);
            $data['photo'] = 'uploads/' . $newName;
        }

        if ($this->candidateModel->insert($data)) {
            return redirect()->to('/admin/candidates')->with('success', 'Kandidat berhasil ditambahkan!');
        } else {
            return redirect()->back()->with('error', 'Gagal menambahkan kandidat!');
        }
    }

    public function editCandidate($id)
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $candidate = $this->candidateModel->find($id);

        if (!$candidate) {
            return redirect()->to('/admin/candidates')->with('error', 'Kandidat tidak ditemukan!');
        }

        return view('admin/edit_candidate', [
            'candidate' => $candidate,
        ]);
    }

    public function updateCandidateProcess($id)
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $rules = [
            'name'        => 'required|string',
            'description' => 'string',
            'vision'      => 'string',
            'mission'     => 'string',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'name'        => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'vision'      => $this->request->getPost('vision'),
            'mission'     => $this->request->getPost('mission'),
        ];

        // Handle photo upload with validation and remove old file when replaced
        $photo = $this->request->getFile('photo');
        if ($photo && $photo->isValid() && !$photo->hasMoved()) {
            $allowedMime = ['image/jpeg', 'image/png', 'image/gif'];
            $maxSize = 5 * 1024 * 1024; // 5MB

            if (!in_array($photo->getClientMimeType(), $allowedMime)) {
                return redirect()->back()->withInput()->with('error', 'Format foto tidak didukung. Hanya JPG, PNG, GIF.');
            }

            if ($photo->getSize() > $maxSize) {
                return redirect()->back()->withInput()->with('error', 'Ukuran foto maksimal 5MB.');
            }

            // delete old photo if exists
            $existing = $this->candidateModel->find($id);
            if ($existing && !empty($existing['photo'])) {
                $oldPath = ROOTPATH . 'public/' . $existing['photo'];
                if (is_file($oldPath)) {
                    @unlink($oldPath);
                }
            }

            $newName = $photo->getRandomName();
            $photo->move(ROOTPATH . 'public/uploads/', $newName);
            $data['photo'] = 'uploads/' . $newName;
        }

        if ($this->candidateModel->update($id, $data)) {
            return redirect()->to('/admin/candidates')->with('success', 'Kandidat berhasil diperbarui!');
        } else {
            return redirect()->back()->with('error', 'Gagal memperbarui kandidat!');
        }
    }

    public function deleteCandidate($id)
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        if ($this->candidateModel->delete($id)) {
            return redirect()->to('/admin/candidates')->with('success', 'Kandidat berhasil dihapus!');
        } else {
            return redirect()->back()->with('error', 'Gagal menghapus kandidat!');
        }
    }

    public function voters()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        $voters = $this->userModel->where('role', 'voter')->findAll();

        return view('admin/voters', [
            'voters' => $voters,
        ]);
    }

    public function resetVoting()
    {
        $check = $this->checkAdmin();
        if ($check) return $check;

        // Reset all votes
        $db = \Config\Database::connect();
        $db->query('TRUNCATE TABLE votes');
        $this->userModel->query('UPDATE users SET has_voted = 0');
        $this->candidateModel->query('UPDATE candidates SET vote_count = 0');

        return redirect()->to('/admin/dashboard')->with('success', 'Voting berhasil direset!');
    }
}
