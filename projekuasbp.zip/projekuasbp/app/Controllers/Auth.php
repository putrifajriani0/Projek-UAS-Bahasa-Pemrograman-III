<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function welcome()
    {
        if (session()->get("user_id")) {
            $role = session()->get("role");
            if ($role === "admin") {
                return redirect()->to("/admin/dashboard");
            }
            return redirect()->to("/voting");
        }
        return view("auth/welcome");
    }

    public function index()
    {
        if (session()->get('user_id')) {
            // Redirect based on role: admin -> admin dashboard, voter -> voting page
            $role = session()->get('role');
            if ($role === 'admin') {
                return redirect()->to('/admin/dashboard');
            }
            return redirect()->to('/voting');
        }
        return view('auth/login');
    }

    public function register()
    {
        if (session()->get('user_id')) {
            return redirect()->to('/voting');
        }
        return view('auth/register');
    }

    public function registerProcess()
    {
        $rules = [
            'username'  => 'required|alpha_numeric|is_unique[users.username]',
            'email'     => 'required|valid_email|is_unique[users.email]',
            'password'  => 'required|min_length[6]',
            'confirm_password' => 'required|matches[password]',
            'full_name' => 'required|string',
            'nik'       => 'required|numeric|exact_length[16]|is_unique[users.nik]',
        ];

        if (!$this->validate($rules)) {
            $errors = $this->validator->getErrors();
            log_message('warning', 'Register validation failed: ' . json_encode($errors));
            return redirect()->back()->withInput()->with('errors', $errors);
        }

        $data = [
            'username'  => $this->request->getPost('username'),
            'email'     => $this->request->getPost('email'),
            'password'  => $this->request->getPost('password'),
            'full_name' => $this->request->getPost('full_name'),
            'nik'       => $this->request->getPost('nik'),
            'role'      => 'voter',
        ];

        if ($this->userModel->register($data)) {
            log_message('info', 'User registered successfully: ' . $data['username']);
            return redirect()->to('/auth/login')->with('success', 'Registrasi berhasil! Silakan login.');
        } else {
            $errors = $this->userModel->errors();
            log_message('error', 'Register insert failed: ' . json_encode($errors));
            return redirect()->back()->with('error', 'Registrasi gagal! ' . json_encode($errors));
        }
    }

    public function login()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        if (!$username || !$password) {
            return redirect()->back()->with('error', 'Username dan password harus diisi!');
        }

        $user = $this->userModel->login($username, $password);

        if ($user) {
            session()->set([
                'user_id'   => $user['id'],
                'username'  => $user['username'],
                'email'     => $user['email'],
                'full_name' => $user['full_name'],
                'role'      => $user['role'],
                'has_voted' => $user['has_voted'],
            ]);

            if ($user['role'] === 'admin') {
                return redirect()->to('/admin/dashboard');
            } else {
                return redirect()->to('/voting');
            }
        } else {
            log_message('error', 'Login failed for user: ' . $username);
            return redirect()->back()->with('error', 'Username atau password salah!');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/')->with('success', 'Anda berhasil logout!');
    }
}
