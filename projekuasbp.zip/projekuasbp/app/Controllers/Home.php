<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('auth/login');
    }
    public function register(): string
    {
        return view('auth/register');
    }
    public function voting(): string
    {
        return view('voting/voting');
    }
    public function results(): string
    {
        return view('voting/results'); 
    }
    public function adminDashboard(): string
    {
        return view('admin/dashboard');
    }
    public function adminCandidates(): string
    {
        return view('admin/candidates');
    }
    public function adminAddCandidate(): string
    {
        return view('admin/add_candidate');
    }
    public function adminEditCandidate(): string
    {
        return view('admin/edit_candidate');
    }
    public function adminVoters(): string
    {
        return view('admin/voters');
    }
    public function notFound(): string
    {
        return view('errors/html/error_404');
    }
    public function internalError(): string
    {
        return view('errors/html/error_500');
    }
    public function forbidden(): string
    {
        return view('errors/html/error_403');
    }
    
}
