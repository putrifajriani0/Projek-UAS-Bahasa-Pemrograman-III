<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Redirect home to welcome page
$routes->get('/', 'Auth::welcome');

// Auth Routes
$routes->get('auth/login', 'Auth::index');
$routes->post('auth/login', 'Auth::login');


$routes->get('auth/register', 'Auth::register');
$routes->post('auth/registerProcess', 'Auth::registerProcess');
$routes->get('auth/logout', 'Auth::logout');

// Voting Routes
$routes->get('voting', 'Voting::index');
$routes->post('voting/cast', 'Voting::cast');
$routes->get('voting/results', 'Voting::results');

// Admin Routes
$routes->get('admin/dashboard', 'Admin::dashboard');
$routes->get('admin/candidates', 'Admin::candidates');
$routes->get('admin/candidatesAjax', 'Admin::candidatesAjax');
$routes->get('admin/addCandidate', 'Admin::addCandidate');
$routes->post('admin/saveCandidateProcess', 'Admin::saveCandidateProcess');
$routes->get('admin/editCandidate/(:num)', 'Admin::editCandidate/$1');
$routes->post('admin/updateCandidateProcess/(:num)', 'Admin::updateCandidateProcess/$1');
$routes->get('admin/deleteCandidate/(:num)', 'Admin::deleteCandidate/$1');
$routes->get('admin/voters', 'Admin::voters');
$routes->get('admin/resetVoting', 'Admin::resetVoting');
