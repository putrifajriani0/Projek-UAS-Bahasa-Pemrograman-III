#!/usr/bin/env php
<?php

// Test Script untuk Debug Foto Kandidat

echo "===================================\n";
echo "TEST: Foto Kandidat Debug Script\n";
echo "===================================\n\n";

// Test 1: Check folder exists
echo "[TEST 1] Cek folder uploads...\n";
$uploadDir = __DIR__ . '/public/uploads';
if (is_dir($uploadDir)) {
    echo "✓ Folder uploads ada di: $uploadDir\n";
    $files = scandir($uploadDir);
    $imageCount = count(array_filter($files, function($f) {
        return in_array(strtolower(pathinfo($f, PATHINFO_EXTENSION)), ['jpg', 'png', 'gif']);
    }));
    echo "  Total file foto: $imageCount\n\n";
} else {
    echo "✗ Folder uploads TIDAK ada!\n\n";
}

// Test 2: Check database
echo "[TEST 2] Cek database candidates...\n";
try {
    $mysqli = new mysqli('localhost', 'root', '', 'evoting_db');
    if ($mysqli->connect_error) {
        throw new Exception('Connection Error: ' . $mysqli->connect_error);
    }
    
    $result = $mysqli->query('SELECT id, name, photo, vote_count FROM candidates');
    if (!$result) {
        throw new Exception('Query Error: ' . $mysqli->error);
    }
    
    $count = 0;
    echo "Kandidat yang terdaftar:\n";
    echo str_repeat("-", 80) . "\n";
    printf("%-3s | %-20s | %-40s | %s\n", "ID", "Nama", "Path Foto", "Vote");
    echo str_repeat("-", 80) . "\n";
    
    while ($row = $result->fetch_assoc()) {
        $count++;
        $photoStatus = $row['photo'] ? "✓ " . basename($row['photo']) : "✗ Kosong";
        printf("%-3d | %-20s | %-40s | %d\n", $row['id'], substr($row['name'], 0, 20), $photoStatus, $row['vote_count']);
    }
    
    echo str_repeat("-", 80) . "\n";
    echo "Total kandidat: $count\n\n";
    
    $mysqli->close();
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n\n";
}

// Test 3: Check file existence
echo "[TEST 3] Verifikasi file foto di disk...\n";
try {
    $mysqli = new mysqli('localhost', 'root', '', 'evoting_db');
    $result = $mysqli->query('SELECT id, name, photo FROM candidates WHERE photo IS NOT NULL AND photo != ""');
    
    $foundCount = 0;
    $missingCount = 0;
    
    while ($row = $result->fetch_assoc()) {
        $filePath = __DIR__ . '/public/' . $row['photo'];
        if (file_exists($filePath)) {
            $foundCount++;
            echo "✓ [ID {$row['id']}] {$row['name']} -> Ditemukan ({$row['photo']})\n";
        } else {
            $missingCount++;
            echo "✗ [ID {$row['id']}] {$row['name']} -> TIDAK DITEMUKAN ({$row['photo']})\n";
        }
    }
    
    echo "\nRingkasan: $foundCount ditemukan, $missingCount tidak ditemukan\n\n";
    $mysqli->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n\n";
}

// Test 4: Verify base_url path
echo "[TEST 4] Contoh path yang seharusnya di-generate...\n";
echo "Jika base_url() = 'http://localhost:8080/'\n";
echo "Maka foto path seharusnya: 'http://localhost:8080/uploads/filename.jpg'\n\n";

echo "===================================\n";
echo "Test selesai!\n";
echo "===================================\n";
