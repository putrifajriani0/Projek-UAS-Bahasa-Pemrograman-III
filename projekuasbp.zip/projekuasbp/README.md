# 🗳️ E-Voting MAN 1 AGAM - Sistem Pemilihan Umum Organisasi Siswa

## 📋 Pengenalan

**E-Voting MAN 1 AGAM** adalah sistem pemilihan umum online berbasis web yang dibangun dengan **CodeIgniter 4** dan **MySQL**. Sistem ini memungkinkan siswa/siswi untuk melakukan voting secara digital dengan aman, transparan, dan terpercaya.

---

## ✨ Fitur Utama

✅ **Autentikasi Aman**: Login & Register dengan password encryption (BCRYPT)  
✅ **Session Management**: Tracking pemilih real-time  
✅ **Voting System**: Interface intuitif dengan proteksi double voting  
✅ **Admin Dashboard**: Manage kandidat + lihat hasil voting real-time  
✅ **Responsive Design**: Bootstrap 5 - optimal di desktop & mobile  
✅ **Data Validation**: Server-side + client-side validation  
✅ **AJAX Integration**: Candidate listing refresh tanpa reload  
✅ **Visualisasi Data**: Chart.js untuk grafik hasil voting  
✅ **Multiple Tables**: Users, Candidates, Votes dengan relasi one-to-many  

---

## 🛠️ Teknologi

| Komponen | Teknologi |
|----------|-----------|
| Backend | PHP 7.4+ / CodeIgniter 4 |
| Database | MySQL / MariaDB |
| Frontend | Bootstrap 5, jQuery, Chart.js |
| Security | BCRYPT, Sessions, CSRF Protection |

---

## 📦 Instalasi & Setup

### Prasyarat
- PHP 7.4 atau lebih tinggi
- MySQL / MariaDB
- Composer
- VS Code / Text Editor

### 1️⃣ Persiapan Awal

```bash
# Copy environment file
copy .env.example .env

# Atau di Linux/Mac:
cp .env.example .env
```

### 2️⃣ Konfigurasi Database

Edit file `.env`:
```ini
CI_ENVIRONMENT = development

# Database Settings
database.default.DBDriver = MySQLi
database.default.hostname = localhost
database.default.database = evoting_db
database.default.username = root
database.default.password = 

# App Settings
app.baseURL = 'http://localhost:8080/'
```

### 3️⃣ Buat Database

**Menggunakan PHPMyAdmin:**
1. Buka http://localhost/phpmyadmin
2. Klik "New" atau "Buat Database Baru"
3. Masukkan nama: `evoting_db`
4. Klik "Create"

**Atau menggunakan Command:**
```sql
CREATE DATABASE IF NOT EXISTS evoting_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 4️⃣ Jalankan Migrations

```bash
cd d:\VS CODE\e-voting-man
php spark migrate
```

✅ Output yang diharapkan:
```
Running all new migrations...
Migrating up...
[2025-12-15-000001_CreateUsersTable.php]
[2025-12-15-000002_CreateCandidatesTable.php]
[2025-12-15-000003_CreateVotesTable.php]
Done.
```

### 5️⃣ Jalankan Server

```bash
php spark serve
```

✅ Aplikasi berjalan di: **http://localhost:8080**

---

## 🎯 Penggunaan Aplikasi

### 📝 Registrasi Pemilih

1. Buka http://localhost:8080
2. Klik "Belum punya akun? Daftar di sini"
3. Isi form dengan:
   - Username (4-20 karakter, alfanumerik)
   - Email (valid)
   - Nama Lengkap
   - NIK (16 digit)
   - Password (min 6 karakter)
   - Konfirmasi Password
4. Klik "Daftar"

### 🔐 Login

1. Masukkan **Username** atau bisa gunakan test account berikut:
   - Username: `testuser`
   - Password: `password123`
2. Masukkan Password
3. Klik "Login"

### 🗳️ Voting

**Sebagai Pemilih:**
1. Setelah login, pilih kandidat favorit Anda
2. Klik tombol "Pilih" pada kartu kandidat
3. Lihat konfirmasi pilihan Anda
4. Klik "Serahkan Suara" untuk menyelesaikan voting
5. ✅ Suara Anda tercatat! (Hanya bisa voting 1x)

### 👨‍💼 Admin Panel

**Login sebagai Admin:**
1. Username: `admin`
2. Password: `admin123`

**Fitur Admin:**
- **Dashboard**: Lihat statistik voting real-time (total pemilih, sudah voting, belum voting, total kandidat)
- **Manage Kandidat**: 
  - ➕ Tambah kandidat baru (nama, foto, visi, misi)
  - ✏️ Edit kandidat
  - 🗑️ Hapus kandidat
- **Daftar Pemilih**: Lihat semua pemilih dan status voting mereka
- **Reset Voting**: Reset semua data voting (hati-hati!)

---

## 📊 Struktur Database

### Tabel Users
```sql
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(150),
  nik VARCHAR(16) UNIQUE NOT NULL,
  role ENUM('admin', 'voter') DEFAULT 'voter',
  has_voted BOOLEAN DEFAULT FALSE,
  created_at DATETIME,
  updated_at DATETIME
);
```

### Tabel Candidates
```sql
CREATE TABLE candidates (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  photo VARCHAR(255),
  vision TEXT,
  mission TEXT,
  vote_count INT DEFAULT 0,
  status ENUM('active', 'inactive') DEFAULT 'active',
  created_at DATETIME,
  updated_at DATETIME
);
```

### Tabel Votes
```sql
CREATE TABLE votes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT NOT NULL,
  candidate_id INT NOT NULL,
  created_at DATETIME,
  updated_at DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
);
```

---

## 🔌 API Endpoints

| Method | Endpoint | Deskripsi | Auth |
|--------|----------|-----------|------|
| GET | `/` | Home page | - |
| GET | `/auth/login` | Login form | - |
| POST | `/auth/login` | Process login | - |
| GET | `/auth/register` | Register form | - |
| POST | `/auth/register` | Process register | - |
| GET | `/auth/logout` | Logout | ✓ |
| GET | `/voting` | Halaman voting | ✓ Voter |
| POST | `/voting/castVote` | Submit voting | ✓ Voter |
| GET | `/voting/results` | Hasil voting | ✓ |
| GET | `/admin/dashboard` | Admin dashboard | ✓ Admin |
| GET | `/admin/candidates` | Daftar kandidat | ✓ Admin |
| GET | `/admin/candidatesAjax` | Kandidat (JSON) | ✓ Admin |
| POST | `/admin/saveCandidateProcess` | Simpan kandidat baru | ✓ Admin |
| GET | `/admin/editCandidate/:id` | Edit form kandidat | ✓ Admin |
| POST | `/admin/updateCandidateProcess/:id` | Update kandidat | ✓ Admin |
| POST | `/admin/deleteCandidate/:id` | Hapus kandidat | ✓ Admin |
| GET | `/admin/voters` | Daftar pemilih | ✓ Admin |
| POST | `/admin/resetVoting` | Reset voting | ✓ Admin |

---

## 🔒 Fitur Keamanan

### 1. Password Hashing
```php
// Register: Password di-hash dengan BCRYPT
password_hash($password, PASSWORD_BCRYPT)

// Login: Verifikasi password
password_verify($input_password, $hashed_password)
```

### 2. CSRF Protection
Semua form menggunakan CSRF token:
```php
<?= csrf_field() ?>
```

### 3. Session Management
- Session ID unik untuk setiap user
- Auto-logout jika session expire
- Protected routes dengan filter authentication

### 4. Input Validation
- Server-side: Regex, min/max length, format validation
- Client-side: Real-time form checking via JavaScript

### 5. Proteksi Double Voting
```php
// Check: Apakah user sudah voting?
$alreadyVoted = $userModel->hasVoted($userId);

// Mark: Set has_voted = true setelah voting
$userModel->markAsVoted($userId);
```

---

## 📁 Struktur Project

```
e-voting-man/
├── app/
│   ├── Config/
│   │   ├── Routes.php                    # URL routing
│   │   ├── Database.php                  # Database config
│   │   └── Constants.php                 # App constants
│   ├── Controllers/
│   │   ├── Auth.php                      # Login/Register logic
│   │   ├── Voting.php                    # Voting logic
│   │   ├── Admin.php                     # Admin panel
│   │   └── Home.php                      # Home controller
│   ├── Models/
│   │   ├── UserModel.php                 # User CRUD + Auth
│   │   ├── CandidateModel.php            # Candidate CRUD
│   │   └── VoteModel.php                 # Vote operations
│   ├── Database/
│   │   └── Migrations/
│   │       ├── 2025-12-15-000001_CreateUsersTable.php
│   │       ├── 2025-12-15-000002_CreateCandidatesTable.php
│   │       └── 2025-12-15-000003_CreateVotesTable.php
│   └── Views/
│       ├── layout/
│       │   └── main.php                  # Master layout template
│       ├── partials/
│       │   └── nav.php                   # Dynamic navigation
│       ├── auth/
│       │   ├── login.php
│       │   ├── register.php
│       │   └── welcome.php
│       ├── voting/
│       │   ├── voting.php                # Voting form
│       │   └── results.php               # Results display
│       └── admin/
│           ├── dashboard.php
│           ├── candidates.php
│           ├── add_candidate.php
│           ├── edit_candidate.php
│           └── voters.php
├── public/
│   ├── index.php
│   └── uploads/                          # Photo storage
├── .env.example                          # Environment template
├── phpunit.xml.dist                      # Unit testing config
└── composer.json                         # Dependencies
```

---

## 🧪 Testing & Debugging

### Test Account (Admin)
```
Username: admin
Password: admin123
```

### Test Account (Voter)
```
Username: testuser
Password: password123
```

### Create Test Account via CLI
```bash
php spark db:seed UserSeeder
```

### View Database via CLI
```bash
php spark tinker
# Then:
> $users = \App\Models\UserModel::all();
> print_r($users);
```

### Debug Mode
Edit `.env`:
```ini
CI_ENVIRONMENT = development
```

View logs at: `writable/logs/`

---

## 🐛 Troubleshooting

### ❌ Error: "Connection refused"
**Solusi:**
- Pastikan MySQL running: Start "MySQL Server" di Services (Windows)
- Cek `.env` database credentials

### ❌ Error: "Table doesn't exist"
**Solusi:**
```bash
php spark migrate:refresh
php spark migrate
```

### ❌ Error: "Upload folder not writable"
**Solusi:**
- Edit folder permissions: `public/uploads/` → chmod 755 (Linux/Mac)
- Atau create folder jika belum ada

### ❌ CSRF Token Mismatch
**Solusi:**
- Clear browser cookies & cache
- Ensure session.save_path is writable (`writable/session/`)

### ❌ Cannot Login
**Solusi:**
```bash
php spark tinker
> $model = new \App\Models\UserModel();
> $model->update(1, ['password' => password_hash('admin123', PASSWORD_BCRYPT)]);
```

---

## 📚 Developer Guide

### Menambah Route Baru
Edit `app/Config/Routes.php`:
```php
$routes->group('admin', ['filter' => 'auth'], static function($routes) {
    $routes->get('newpage', 'Admin::newpage');
    $routes->post('saveNewpage', 'Admin::saveNewpage');
});
```

### Menambah View Baru
1. Buat file di `app/Views/`
2. Extend layout:
```php
<?php $title = 'Page Title' ?>
<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>
<!-- Content here -->
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<!-- JavaScript here -->
<?= $this->endSection() ?>
```

### Menambah Model CRUD
```php
namespace App\Models;
use CodeIgniter\Model;

class MyModel extends Model {
    protected $table = 'my_table';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['field1', 'field2'];
}
```

---

## 📝 Checklist Implementasi

- ✅ Database: 3 tables (users, candidates, votes)
- ✅ Relationships: one-to-many (users→votes, candidates→votes)
- ✅ Authentication: Login + Register dengan validation
- ✅ CRUD: Candidates module (Create, Read, Update, Delete)
- ✅ Voting: Cast vote + check already voted
- ✅ Admin: Dashboard dengan statistics & charts
- ✅ AJAX: Candidate list dynamic loading
- ✅ Layout: Bootstrap 5 responsive design
- ✅ Validation: Server-side + client-side
- ✅ CSRF: Protection di semua forms
- ✅ File Upload: Photo upload dengan validation
- ✅ Security: Password hashing + session management

---

## 📄 Lisensi

Proyek ini dibuat untuk keperluan akademik - Ujian Akhir Semester Bahasa Pemrograman III.

---

## 👨‍💻 Author

**Name**: Student Developer  
**Course**: Bahasa Pemrograman III (Programming Language III)  
**School**: MAN 1 AGAM  
**Date**: December 2024

---

## 🆘 Support & Issues

Untuk pertanyaan atau issue, hubungi:
- 📧 Email: support@evoting-agam.local
- 💬 Discord: [Link komunitas]
- 📞 WhatsApp: [Contact admin]

---

**Last Updated**: December 2024  
**Version**: 1.0.0  
**Status**: Production Ready ✅
